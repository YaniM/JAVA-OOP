package first;

public interface Identifiable {
    String getId();
}
