package first;

public interface Person extends Buyer {
    String getName();
    int getAge();
}
