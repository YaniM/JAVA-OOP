package military;

import java.util.List;

public interface ILeutenant extends ISoldier{

    public void addPrivate(PrivateImpl priv);
}
