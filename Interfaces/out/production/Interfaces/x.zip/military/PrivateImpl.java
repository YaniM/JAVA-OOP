package military;

public class PrivateImpl extends SoldierImpl implements IPrivate {
    private double salary;

    public PrivateImpl(int id,String firstName, String lastName,double salary) {
        super(id,firstName, lastName);
        this.salary = salary;
    }

    @Override
    public double getSalary() {
        return this.salary;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());

        sb.append(" Salary: ").append(String.format("%.2f",this.getSalary())).append(System.lineSeparator());
        return sb.toString();
    }
}
