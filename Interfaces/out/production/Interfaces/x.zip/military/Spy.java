package military;

public class Spy extends SoldierImpl implements Ispy {
    private String codeNumber;

    public Spy(int id, String firstName, String lastName, String codeNumber) {
        super(id, firstName, lastName);
        this.codeNumber = codeNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());

        sb.append("Code Number: ").append(this.codeNumber).append(System.lineSeparator());

        return sb.toString();
    }
}
