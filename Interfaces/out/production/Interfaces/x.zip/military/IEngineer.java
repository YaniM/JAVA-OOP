package military;

public interface IEngineer extends ISoldier {
    public void addRepair(Repair repair);
}
