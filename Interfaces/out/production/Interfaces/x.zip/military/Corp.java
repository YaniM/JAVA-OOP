package military;

public enum  Corp {
    Airforces,
    Marines,
}
