package military;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Commado extends SpecialisedSoldierImpl implements ICommado {

    private Set<Mission> missions;

    public Commado(int id, String firstName, String lastName, double salary, Corp corps) {
        super(id, firstName, lastName, salary, corps);
        this.missions = new LinkedHashSet<>();
    }

    @Override
    public void addMission(Mission mission) {
        this.missions.add(mission);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(System.lineSeparator()).append("Missions:");
        if(this.missions.size()==0){
            return sb.toString();
        }
        for (Mission mission : missions) {
            sb.append(mission.toString()).append(System.lineSeparator());
        }

        return sb.toString();
    }
}
