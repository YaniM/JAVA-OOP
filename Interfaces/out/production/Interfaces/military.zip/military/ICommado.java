package military;

public interface ICommado extends ISoldier {
    public void addMission(Mission mission);
}
