package military;

public interface ISoldier {
    int getId();
    String getFirstName();
    String getLastName();

    String toString();
}
