package military;

public interface IPrivate extends ISoldier {
    double getSalary();
}
