package military;

public interface ISpecialised extends ISoldier {
}
