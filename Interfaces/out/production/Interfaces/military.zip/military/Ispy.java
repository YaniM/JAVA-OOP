package military;

public interface Ispy extends ISoldier {
}
