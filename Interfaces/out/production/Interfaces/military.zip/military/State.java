package military;

public enum State {
    inProgress,
    Finished,
}
