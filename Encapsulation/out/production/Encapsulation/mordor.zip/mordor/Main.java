package mordor;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] foods = scanner.nextLine().split(" ");

        Gandalf gandalf = new Gandalf();

        if (foods.length >= 1 && foods.length <= 100 && Arrays.toString(foods).length() < 1000) {
            for (int i = 0; i < foods.length; i++) {
                gandalf.eatFood(foods[i].toLowerCase());
            }
        }

        System.out.println(gandalf.getFoodPoints());
        System.out.println(gandalf.getMood());
    }
}
